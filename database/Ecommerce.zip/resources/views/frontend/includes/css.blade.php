<link rel="shortcut icon" href="{{ asset('frontend') }}/assets/images/logo/favicon.png">

<!-- fraimwork - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/bootstrap.min.css">

<!-- icon font - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/fontawesome.css">
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/stroke-gap-icons.css">
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/icofont.css">

<!-- animation - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/animate.css">

<!-- carousel - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/slick.css">
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/slick-theme.css">

<!-- popup - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/magnific-popup.css">

<!-- jquery-ui - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/jquery-ui.css">

<!-- select option - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/nice-select.css">

<!-- woocommercen - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/woocommerce.css">

<!-- custom - css include -->
<link rel="stylesheet" type="text/css" href="{{ asset('frontend') }}/assets/css/style.css">
